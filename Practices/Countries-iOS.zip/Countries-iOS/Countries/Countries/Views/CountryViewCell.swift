//
//  CountryViewCell.swift
//  Countries
//
//  Created by Rafael Veronezi on 27/01/18.
//  Copyright © 2018 Caeno. All rights reserved.
//

import UIKit

class CountryViewCell: UITableViewCell {

    //
    // MARK: - Properties
    var country: Country? {
        didSet {
            if let country = country {
                nameLabel.text = country.name
                capitalLabel.text = "Capital: \(country.capital)"
            }
        }
    }
    
    
    //
    // MARK: - Outlets
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var capitalLabel: UILabel!
    @IBOutlet weak var flagImageView: UIImageView!
    
}
