//
//  CountryList.swift
//  Countries
//
//  Created by Rafael Veronezi on 27/01/18.
//  Copyright © 2018 Caeno. All rights reserved.
//

import UIKit

class CountryList: NSObject {
    
    //
    // MARK: - Properties
    
    var countries: [Country]
    
    //
    // MARK: - Initializers
    
    override init() {
        // Some sample data to start with
        self.countries = [
            Country(code: "AR", name: "Argentina", capital: "Buenos Aires", continent: "South America", population: 41343201, area: 2766890.0),
            Country(code: "BR", name: "Brazil", capital: "Brasília", continent: "South America", population: 201103330, area: 8511965.0),
            Country(code: "FR", name: "France", capital: "Paris", continent: "Europe", population: 41343201, area: 2766890.0),
            Country(code: "IT", name: "Italy", capital: "Rome", continent: "South America", population: 41343201, area: 2766890.0),
            Country(code: "US", name: "United States", capital: "Washington", continent: "North America", population: 41343201, area: 2766890.0)
        ]
        
        super.init()
    }
    
    //
    // MARK: - Methods

    /**
     Recarrega a lista de países dessa instância usando os dados fornecidos pelo serviço GeoNames. A operação executa de maneira assíncrona.
     
     - parameter completionHandler: Um closure opcional para ser executado após a operação ser concluída.
     */
    func refreshListFromGeonamesService(language localeCode: String? = nil, _ completionHandler: ((_ success: Bool) -> ())?) {
        // Produz um delay artificial
        let when = DispatchTime.now() + 1.5
        DispatchQueue.main.asyncAfter(deadline: when) {
            if let c = completionHandler {
                DispatchQueue.main.async {
                    c(false)
                }
            }
        }
    }
}
